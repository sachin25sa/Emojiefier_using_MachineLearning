import streamlit as st
import base64
import os
from PIL import Image
st.set_page_config(layout="wide")

st.title('Text, Speech, Visual -> Emoji')

st.image(Image.open('data/image.jpg'))